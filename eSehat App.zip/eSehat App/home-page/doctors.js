// Sample doctor data
const doctorsData = [
    {
        id: 1,
        name: "Dr. Rajesh Kumar",
        specialty: "Cardiology",
        experience: "15 years",
        image: "https://placehold.co/300x300/2a7cc7/white?text=Dr.+Rajesh",
        bio: "Senior Cardiologist with extensive experience in interventional procedures. Specializes in angioplasty and heart disease management.",
        availability: ["Monday", "Wednesday", "Friday"],
        education: "MBBS, MD (Cardiology), DM (Cardiology)",
        awards: ["Best Cardiologist Award 2020", "Excellence in Medical Practice 2019"]
    },
    {
        id: 2,
        name: "Dr. Priya Sharma",
        specialty: "Pediatrics",
        experience: "12 years",
        image: "https://placehold.co/300x300/28a745/white?text=Dr.+Priya",
        bio: "Pediatrician dedicated to providing comprehensive healthcare for infants, children and adolescents.",
        availability: ["Tuesday", "Thursday", "Saturday"],
        education: "MBBS, MD (Pediatrics)",
        awards: ["Child Healthcare Excellence Award 2021"]
    },
    {
        id: 3,
        name: "Dr. Amit Singh",
        specialty: "Orthopedics",
        experience: "18 years",
        image: "https://placehold.co/300x300/dc3545/white?text=Dr.+Amit",
        bio: "Orthopedic surgeon specializing in joint replacement, arthroscopy, and sports medicine.",
        availability: ["Monday", "Tuesday", "Thursday", "Friday"],
        education: "MBBS, MS (Orthopedics), Fellowship in Joint Replacement",
        awards: ["Excellence in Orthopedic Surgery 2018"]
    },
    {
        id: 4,
        name: "Dr. Sunita Patel",
        specialty: "Gynecology",
        experience: "14 years",
        image: "https://placehold.co/300x300/6f42c1/white?text=Dr.+Sunita",
        bio: "Gynecologist and obstetrician with expertise in minimally invasive surgeries and high-risk pregnancies.",
        availability: ["Monday", "Wednesday", "Friday", "Saturday"],
        education: "MBBS, MD (Gynecology), FMAS",
        awards: ["Women's Health Champion Award 2019"]
    },
    {
        id: 5,
        name: "Dr. Vikram Malhotra",
        specialty: "Neurology",
        experience: "20 years",
        image: "https://placehold.co/300x300/fd7e14/white?text=Dr.+Vikram",
        bio: "Neurologist specializing in the treatment of stroke, epilepsy, and movement disorders.",
        availability: ["Tuesday", "Thursday", "Saturday"],
        education: "MBBS, MD (Medicine), DM (Neurology)",
        awards: ["Neurology Excellence Award 2020", "Research Pioneer in Neuroscience"]
    },
    {
        id: 6,
        name: "Dr. Anjali Mehta",
        specialty: "Dermatology",
        experience: "10 years",
        image: "https://placehold.co/300x300/20c997/white?text=Dr.+Anjali",
        bio: "Dermatologist with expertise in cosmetic dermatology, laser treatments, and skin disorders.",
        availability: ["Monday", "Wednesday", "Friday", "Saturday"],
        education: "MBBS, MD (Dermatology), Fellowship in Cosmetic Dermatology",
        awards: ["Dermatology Innovation Award 2021"]
    },
    {
        id: 7,
        name: "Dr. Sanjay Verma",
        specialty: "General Medicine",
        experience: "22 years",
        image: "https://placehold.co/300x300/6c757d/white?text=Dr.+Sanjay",
        bio: "General physician with extensive experience in internal medicine and chronic disease management.",
        availability: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        education: "MBBS, MD (General Medicine)",
        awards: ["Lifetime Achievement in Medicine 2020"]
    },
    {
        id: 8,
        name: "Dr. Neha Gupta",
        specialty: "Cardiology",
        experience: "9 years",
        image: "https://placehold.co/300x300/2a7cc7/white?text=Dr.+Neha",
        bio: "Cardiologist specializing in non-invasive cardiology and preventive heart care.",
        availability: ["Tuesday", "Thursday", "Saturday"],
        education: "MBBS, MD (Medicine), DM (Cardiology)",
        awards: ["Young Cardiologist of the Year 2019"]
    }
];

// DOM Elements
const doctorsGrid = document.getElementById('doctorsGrid');
const doctorModal = document.getElementById('doctorModal');
const modalBody = document.getElementById('modalBody');
const closeModal = document.querySelector('.close-modal');
const loadMoreBtn = document.getElementById('loadMoreDoctors');
const searchInput = document.getElementById('doctorSearch');
const specialtyFilter = document.getElementById('specialtyFilter');
const experienceFilter = document.getElementById('experienceFilter');
const availabilityFilter = document.getElementById('availabilityFilter');
const resetFiltersBtn = document.getElementById('resetFilters');

// Variables
let displayedDoctors = 6;
let filteredDoctors = [...doctorsData];

// Initialize the page
function init() {
    renderDoctors();
    setupEventListeners();
}

// Render doctors to the grid
function renderDoctors() {
    doctorsGrid.innerHTML = '';
    
    const doctorsToShow = filteredDoctors.slice(0, displayedDoctors);
    
    if (doctorsToShow.length === 0) {
        doctorsGrid.innerHTML = `
            <div class="no-results">
                <h3>No doctors found matching your criteria</h3>
                <p>Try adjusting your filters or search terms</p>
            </div>
        `;
        return;
    }
    
    doctorsToShow.forEach(doctor => {
        const doctorCard = document.createElement('div');
        doctorCard.classList.add('doctor-card');
        doctorCard.innerHTML = `
            <div class="doctor-image">
                <img src="${doctor.image}" alt="${doctor.name}">
            </div>
            <div class="doctor-info">
                <h3 class="doctor-name">${doctor.name}</h3>
                <p class="doctor-specialty">${doctor.specialty}</p>
                <p class="doctor-experience">${doctor.experience} experience</p>
                <p class="doctor-bio">${doctor.bio}</p>
                <div class="doctor-actions">
                    <button class="btn-outline view-profile" data-id="${doctor.id}">View Profile</button>
                    <button class="btn-primary book-appointment" data-id="${doctor.id}">Book Appointment</button>
                </div>
            </div>
        `;
        doctorsGrid.appendChild(doctorCard);
    });
    
    // Show or hide load more button
    if (displayedDoctors >= filteredDoctors.length) {
        loadMoreBtn.style.display = 'none';
    } else {
        loadMoreBtn.style.display = 'block';
    }
}

// Setup event listeners
function setupEventListeners() {
    // Load more doctors
    loadMoreBtn.addEventListener('click', () => {
        displayedDoctors += 3;
        renderDoctors();
    });
    
    // Open modal when clicking view profile
    doctorsGrid.addEventListener('click', (e) => {
        if (e.target.classList.contains('view-profile')) {
            const doctorId = parseInt(e.target.getAttribute('data-id'));
            openDoctorModal(doctorId);
        }
        
        if (e.target.classList.contains('book-appointment')) {
            const doctorId = parseInt(e.target.getAttribute('data-id'));
            alert(`Booking appointment with doctor ID: ${doctorId}`);
            // In a real application, this would redirect to the booking page
        }
    });
    
    // Close modal
    closeModal.addEventListener('click', () => {
        doctorModal.style.display = 'none';
    });
    
    // Close modal when clicking outside
    window.addEventListener('click', (e) => {
        if (e.target === doctorModal) {
            doctorModal.style.display = 'none';
        }
    });
    
    // Filter functionality
    searchInput.addEventListener('input', applyFilters);
    specialtyFilter.addEventListener('change', applyFilters);
    experienceFilter.addEventListener('change', applyFilters);
    availabilityFilter.addEventListener('change', applyFilters);
    
    // Reset filters
    resetFiltersBtn.addEventListener('click', resetFilters);
}

// Open doctor modal with details
function openDoctorModal(doctorId) {
    const doctor = doctorsData.find(d => d.id === doctorId);
    
    if (doctor) {
        modalBody.innerHTML = `
            <div class="modal-doctor-header">
                <div class="modal-doctor-image">
                    <img src="${doctor.image}" alt="${doctor.name}">
                </div>
                <div class="modal-doctor-info">
                    <h2>${doctor.name}</h2>
                    <p class="doctor-specialty">${doctor.specialty}</p>
                    <p class="doctor-experience">${doctor.experience} experience</p>
                </div>
            </div>
            <div class="modal-doctor-details">
                <h3>About</h3>
                <p>${doctor.bio}</p>
                
                <h3>Education</h3>
                <p>${doctor.education}</p>
                
                <h3>Availability</h3>
                <p>${doctor.availability.join(', ')}</p>
                
                <h3>Awards & Recognition</h3>
                <ul>
                    ${doctor.awards.map(award => `<li>${award}</li>`).join('')}
                </ul>
            </div>
            <div class="modal-actions">
                <button class="btn-primary">Book Appointment</button>
                <button class="btn-outline">Send Message</button>
            </div>
        `;
        
        doctorModal.style.display = 'block';
    }
}

// Apply filters to doctor list
function applyFilters() {
    const searchTerm = searchInput.value.toLowerCase();
    const specialty = specialtyFilter.value;
    const experience = experienceFilter.value;
    
    filteredDoctors = doctorsData.filter(doctor => {
        // Search filter
        const matchesSearch = doctor.name.toLowerCase().includes(searchTerm) || 
                             doctor.specialty.toLowerCase().includes(searchTerm) ||
                             doctor.bio.toLowerCase().includes(searchTerm);
        
        // Specialty filter
        const matchesSpecialty = specialty === 'all' || doctor.specialty.toLowerCase() === specialty;
        
        // Experience filter
        let matchesExperience = true;
        if (experience !== 'all') {
            const expYears = parseInt(doctor.experience);
            matchesExperience = expYears >= parseInt(experience);
        }
        
        return matchesSearch && matchesSpecialty && matchesExperience;
    });
    
    displayedDoctors = 6;
    renderDoctors();
}

// Reset all filters
function resetFilters() {
    searchInput.value = '';
    specialtyFilter.value = 'all';
    experienceFilter.value = 'all';
    availabilityFilter.value = 'all';
    
    applyFilters();
}

// Initialize the page when DOM is loaded
document.addEventListener('DOMContentLoaded', init);