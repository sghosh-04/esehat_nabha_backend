// medicine-booking.js
// Sample medicine data
const medicines = [
    { id: 1, name: "Paracetamol", brand: "Crocin", price: 25.00, category: "pain-relief", image: "pills" },
    { id: 2, name: "Ibuprofen", brand: "Brufen", price: 35.50, category: "pain-relief", image: "pills" },
    { id: 3, name: "Vitamin C", brand: "Limcee", price: 120.00, category: "vitamins", image: "capsules" },
    { id: 4, name: "Metformin", brand: "Glycomet", price: 45.75, category: "diabetes", image: "pills" },
    { id: 5, name: "Atorvastatin", brand: "Atorva", price: 89.00, category: "cardiac", image: "pills" },
    { id: 6, name: "Amoxicillin", brand: "Mox", price: 65.25, category: "antibiotic", image: "capsules" },
    { id: 7, name: "Omeprazole", brand: "Omez", price: 55.00, category: "gastro", image: "capsules" },
    { id: 8, name: "Multivitamin", brand: "Supradyn", price: 199.00, category: "vitamins", image: "tablets" }
];

// Cart array to store added medicines
let cart = [];

// DOM Elements
const medicinesGrid = document.getElementById('medicinesGrid');
const cartItems = document.getElementById('cartItems');
const cartCount = document.getElementById('cartCount');
const subtotalEl = document.getElementById('subtotal');
const discountEl = document.getElementById('discount');
const totalEl = document.getElementById('total');
const checkoutBtn = document.getElementById('checkoutBtn');
const checkoutModal = document.getElementById('checkoutModal');
const confirmationModal = document.getElementById('confirmationModal');
const closeModalButtons = document.querySelectorAll('.modal .close, .modal .confirmation .close');
const checkoutSubtotal = document.getElementById('checkoutSubtotal');
const checkoutTotal = document.getElementById('checkoutTotal');
const placeOrderBtn = document.getElementById('placeOrderBtn');
const deliveryFeeEl = document.getElementById('deliveryFee');
const orderIdEl = document.getElementById('orderId');
const continueShoppingBtn = document.getElementById('continueShoppingBtn');

const searchInput = document.getElementById('medicineSearch');
const searchBtn = document.getElementById('searchBtn');
const categoryFilter = document.getElementById('categoryFilter');
const sortFilter = document.getElementById('sortFilter');

// Initialize the page
document.addEventListener('DOMContentLoaded', function() {
    renderMedicines(medicines);
    updateCart();

    // Event listeners for modal & buttons
    checkoutBtn.addEventListener('click', openCheckoutModal);
    placeOrderBtn.addEventListener('click', placeOrder);

    closeModalButtons.forEach(button => {
        button.addEventListener('click', closeModals);
    });

    // Tab switching in checkout modal (delegation)
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', function() {
            switchTab(this.getAttribute('data-tab'));
        });
    });

    document.querySelectorAll('.next-tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            switchTab(this.dataset.next);
        });
    });

    // Attach delivery option change
    document.querySelectorAll('input[name="deliveryOption"]').forEach(option => {
        option.addEventListener('change', updateDeliveryFee);
    });

    // Search/filter events
    searchBtn.addEventListener('click', performSearch);
    searchInput.addEventListener('keyup', function(e){
        if (e.key === 'Enter') performSearch();
    });
    categoryFilter.addEventListener('change', performSearch);
    sortFilter.addEventListener('change', performSearch);

    // Continue shopping in confirmation modal
    if (continueShoppingBtn) {
        continueShoppingBtn.addEventListener('click', () => {
            closeModals();
            // keep user on same page to continue shopping
        });
    }

    // close modals when clicking outside content
    window.addEventListener('click', function(event) {
        if (event.target === checkoutModal) closeModals();
        if (event.target === confirmationModal) closeModals();
    });
});

// Render medicines to the grid
function renderMedicines(list) {
    medicinesGrid.innerHTML = '';

    list.forEach(medicine => {
        const medicineCard = document.createElement('div');
        medicineCard.className = 'medicine-card';
        medicineCard.innerHTML = `
            <div class="medicine-image">
                <i class="fas fa-${medicine.image}"></i>
            </div>
            <div class="medicine-name">${medicine.name}</div>
            <div class="medicine-brand">${medicine.brand}</div>
            <div class="medicine-price">₹${medicine.price.toFixed(2)}</div>
            <div class="medicine-actions">
                <div class="quantity-controls">
                    <button class="quantity-btn decrease" data-id="${medicine.id}">-</button>
                    <input type="number" class="quantity-input" id="qty-${medicine.id}" value="1" min="1" readonly>
                    <button class="quantity-btn increase" data-id="${medicine.id}">+</button>
                </div>
                <button class="add-to-cart-btn" data-id="${medicine.id}">Add to Cart</button>
            </div>
        `;
        medicinesGrid.appendChild(medicineCard);
    });

    attachMedicineCardListeners();
}

// attach listeners for buttons inside medicine cards
function attachMedicineCardListeners() {
    document.querySelectorAll('.increase').forEach(button => {
        button.onclick = () => {
            const id = parseInt(button.dataset.id, 10);
            const input = document.getElementById(`qty-${id}`);
            input.value = parseInt(input.value, 10) + 1;
        };
    });

    document.querySelectorAll('.decrease').forEach(button => {
        button.onclick = () => {
            const id = parseInt(button.dataset.id, 10);
            const input = document.getElementById(`qty-${id}`);
            if (parseInt(input.value, 10) > 1) input.value = parseInt(input.value, 10) - 1;
        };
    });

    document.querySelectorAll('.add-to-cart-btn').forEach(button => {
        button.onclick = () => {
            const id = parseInt(button.dataset.id, 10);
            const qty = parseInt(document.getElementById(`qty-${id}`).value, 10);
            addToCart(id, qty);
        };
    });
}

// Add medicine to cart
function addToCart(medicineId, quantity) {
    const medicine = medicines.find(m => m.id === medicineId);
    if (!medicine) return;
    const existingItem = cart.find(item => item.id === medicineId);

    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        cart.push({
            id: medicine.id,
            name: medicine.name,
            brand: medicine.brand,
            price: medicine.price,
            quantity: quantity
        });
    }

    updateCart();
    showNotification(`${quantity} x ${medicine.name} added to cart`);
}

// Remove item from cart
function removeFromCart(medicineId) {
    cart = cart.filter(i => i.id !== medicineId);
    updateCart();
}

// Update quantity in cart
function updateCartQuantity(medicineId, change) {
    const item = cart.find(i => i.id === medicineId);
    if (!item) return;
    item.quantity += change;
    if (item.quantity < 1) removeFromCart(medicineId);
    else updateCart();
}

// Update cart UI and totals
function updateCart() {
    cartItems.innerHTML = '';

    if (cart.length === 0) {
        cartItems.innerHTML = `
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <p>Your cart is empty</p>
                <span>Add medicines from the list</span>
            </div>
        `;
        checkoutBtn.disabled = true;
    } else {
        cart.forEach(item => {
            const el = document.createElement('div');
            el.className = 'cart-item';
            el.innerHTML = `
                <div class="cart-item-info">
                    <div class="cart-item-name">${item.name} <small style="color:#6c7a93">(${item.brand})</small></div>
                    <div class="cart-item-price">₹${(item.price * item.quantity).toFixed(2)}</div>
                </div>
                <div class="cart-item-quantity">
                    <div class="quantity-controls">
                        <button class="quantity-btn decrease" data-id="${item.id}">-</button>
                        <input type="number" class="quantity-input" value="${item.quantity}" min="1" readonly>
                        <button class="quantity-btn increase" data-id="${item.id}">+</button>
                    </div>
                    <button class="remove-item" data-id="${item.id}" title="Remove">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
            cartItems.appendChild(el);
        });

        checkoutBtn.disabled = false;

        // attach listeners for cart item buttons
        cartItems.querySelectorAll('.increase').forEach(b => {
            b.onclick = () => updateCartQuantity(parseInt(b.dataset.id, 10), 1);
        });
        cartItems.querySelectorAll('.decrease').forEach(b => {
            b.onclick = () => updateCartQuantity(parseInt(b.dataset.id, 10), -1);
        });
        cartItems.querySelectorAll('.remove-item').forEach(b => {
            b.onclick = () => removeFromCart(parseInt(b.dataset.id, 10));
        });
    }

    // totals
    const subtotal = cart.reduce((s, i) => s + i.price * i.quantity, 0);
    const discount = subtotal >= 500 ? subtotal * 0.1 : 0; // 10% if >= 500
    const total = subtotal - discount;

    cartCount.textContent = cart.reduce((t, i) => t + i.quantity, 0);
    subtotalEl.textContent = `₹${subtotal.toFixed(2)}`;
    discountEl.textContent = `-₹${discount.toFixed(2)}`;
    totalEl.textContent = `₹${total.toFixed(2)}`;

    if (checkoutSubtotal) checkoutSubtotal.textContent = `₹${subtotal.toFixed(2)}`;
    if (checkoutTotal) checkoutTotal.textContent = `₹${total.toFixed(2)}`;
}

// Open checkout modal
function openCheckoutModal() {
    if (cart.length === 0) return;
    checkoutModal.style.display = 'flex';
    switchTab('delivery');
    updateDeliveryFee();
}

// Close all modals
function closeModals() {
    checkoutModal.style.display = 'none';
    confirmationModal.style.display = 'none';
}

// Switch tabs in checkout modal
function switchTab(tabName) {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(tc => tc.classList.remove('active'));

    const tabEl = document.querySelector(`.tab[data-tab="${tabName}"]`);
    if (tabEl) tabEl.classList.add('active');

    const content = document.getElementById(`${tabName}Tab`);
    if (content) content.classList.add('active');
}

// Select address (delegated)
document.addEventListener('click', function(e) {
    const target = e.target;
    const addressCard = target.closest('.address-card');
    if (addressCard && (target.classList.contains('address-card') || target.closest('.address-card'))) {
        document.querySelectorAll('.address-card').forEach(c => {
            c.classList.remove('selected');
            const btn = c.querySelector('.select-address-btn');
            if (btn) btn.textContent = 'Select';
        });
        addressCard.classList.add('selected');
        const btn = addressCard.querySelector('.select-address-btn');
        if (btn) btn.textContent = 'Selected';
    }
});

// Update delivery fee
function updateDeliveryFee() {
    const expressSelected = document.getElementById('expressDelivery').checked;
    const subtotal = cart.reduce((s, i) => s + i.price * i.quantity, 0);
    const discount = subtotal >= 500 ? subtotal * 0.1 : 0;
    if (expressSelected) {
        deliveryFeeEl.textContent = '₹50';
        checkoutTotal.textContent = `₹${(subtotal - discount + 50).toFixed(2)}`;
    } else {
        deliveryFeeEl.textContent = 'Free';
        checkoutTotal.textContent = `₹${(subtotal - discount).toFixed(2)}`;
    }
}

// Place order
function placeOrder() {
    // simple order id generation
    const tid = 'ESH' + Math.floor(100000 + Math.random() * 900000);
    if (orderIdEl) orderIdEl.textContent = tid;

    // show confirmation
    checkoutModal.style.display = 'none';
    confirmationModal.style.display = 'flex';

    // reset cart
    cart = [];
    updateCart();
}

// Notification helper
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.innerHTML = `<div class="notification-content"><i class="fas fa-check-circle"></i><span>${message}</span></div>`;
    Object.assign(notification.style, {
        position: 'fixed',
        bottom: '20px',
        right: '20px',
        background: '#4caf50',
        color: '#fff',
        padding: '12px 16px',
        borderRadius: '6px',
        boxShadow: '0 6px 18px rgba(0,0,0,0.12)',
        zIndex: 1100,
        opacity: '0',
        transition: 'opacity 220ms'
    });
    document.body.appendChild(notification);
    requestAnimationFrame(()=> notification.style.opacity = '1');
    setTimeout(()=> {
        notification.style.opacity = '0';
        setTimeout(()=> notification.remove(), 250);
    }, 2600);
}

// Search functionality
function performSearch() {
    const term = (searchInput.value || '').trim().toLowerCase();
    const category = (categoryFilter.value || '').trim();
    const sort = (sortFilter.value || 'popularity');

    let filtered = medicines.slice();

    if (term) {
        filtered = filtered.filter(m => m.name.toLowerCase().includes(term) || m.brand.toLowerCase().includes(term) || m.category.toLowerCase().includes(term));
    }

    if (category) {
        filtered = filtered.filter(m => m.category === category);
    }

    switch (sort) {
        case 'price-low':
            filtered.sort((a,b)=> a.price - b.price);
            break;
        case 'price-high':
            filtered.sort((a,b)=> b.price - a.price);
            break;
        case 'name':
            filtered.sort((a,b)=> a.name.localeCompare(b.name));
            break;
        default:
            // popularity — keep the original order
            break;
    }

    if (filtered.length === 0) {
        medicinesGrid.innerHTML = `<div class="no-results" style="text-align:center;padding:30px;color:#6c7a93;">
            <i class="fas fa-search" style="font-size:28px;margin-bottom:8px;display:block;"></i>
            <h3>No medicines found</h3>
            <p>Try different search terms or categories</p>
        </div>`;
    } else {
        renderMedicines(filtered);
    }
}
