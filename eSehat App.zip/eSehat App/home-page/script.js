// Language translation functionality
document.addEventListener('DOMContentLoaded', function() {
    // Language data
    const translations = {
        en: {
            // Navigation
            'home': 'Home',
            'services': 'Services',
            'doctors': 'Doctors',
            'appointments': 'Appointments',
            'health_records': 'Health Records',
            'medicine': 'Medicine',
            'contact': 'Contact',
            
            // Hero section
            'hero_title': 'Your Journey to Better Health Starts Here',
            'hero_desc': 'Access quality healthcare services from the comfort of your home. Book appointments, consult doctors, and manage your health records all in one place.',
            'book_appointment': 'Book an Appointment',
            'consult_online': 'Consult Online',
            
            // Services
            'our_services': 'Our Services',
            'appointment_booking': 'Appointment Booking',
            'appointment_desc': 'Book appointments with specialist doctors at your convenience.',
            'online_consultation': 'Online Consultation',
            'consultation_desc': 'Consult with doctors online through secure video calls.',
            'medicine_delivery': 'Medicine Delivery',
            'medicine_desc': 'Get your prescribed medicines delivered to your doorstep.',
            'health_records': 'Health Records',
            'records_desc': 'Access and manage your health records anytime, anywhere.',
            
            // How it works
            'how_it_works': 'How It Works',
            'create_account': 'Create Account',
            'account_desc': 'Sign up and complete your health profile',
            'choose_service': 'Choose Service',
            'service_desc': 'Select the healthcare service you need',
            'book_appointment_step': 'Book Appointment',
            'appointment_step_desc': 'Schedule your visit or online consultation',
            'get_treatment': 'Get Treatment',
            'treatment_desc': 'Receive quality healthcare and follow-up',
            
            // Testimonials
            'testimonials': 'What Our Patients Say',
            'testimonial_1': '"e-Schat Nabha made it so easy to consult with a specialist without traveling long distances. The video consultation was smooth and the doctor was very helpful."',
            'testimonial_2': '"The medicine delivery service is a lifesaver for my elderly parents. We get all their medications on time without any hassle."',
            'testimonial_3': '"Having all my health records in one place has made managing my chronic condition much easier. I can easily share them with any doctor I consult."',
            'patient': 'Patient',
            'customer': 'Customer',
            
            // Download app
            'download_app': 'Download e-Schat Nabha',
            'download_desc': 'Access healthcare services on the go with our mobile application. Available on both iOS and Android platforms.',
            
            // Footer
            'footer_tagline': 'Your Journey to Better Health Starts Here',
            'quick_links': 'Quick Links',
            'emergency_care': 'Emergency Care',
            'contact_us': 'Contact Us',
            'address': 'Medical Complex, Nabha, Punjab',
            'privacy_policy': 'Privacy Policy',
            'terms_service': 'Terms of Service'
        },
        hi: {
            // Navigation
            'home': 'होम',
            'services': 'सेवाएं',
            'doctors': 'डॉक्टर',
            'appointments': 'अपॉइंटमेंट',
            'health_records': 'हेल्थ रिकॉर्ड्स',
            'medicine': 'दवाई',
            'contact': 'संपर्क',
            
            // Hero section
            'hero_title': 'बेहतर स्वास्थ्य की आपकी यात्रा यहाँ से शुरू होती है',
            'hero_desc': 'अपने घर के आराम से गुणवत्तापूर्ण स्वास्थ्य सेवाओं तक पहुंचें। अपॉइंटमेंट बुक करें, डॉक्टरों से सलाह लें, और अपने स्वास्थ्य रिकॉर्ड को एक ही स्थान पर प्रबंधित करें।',
            'book_appointment': 'अपॉइंटमेंट बुक करें',
            'consult_online': 'ऑनलाइन परामर्श',
            
            // Services
            'our_services': 'हमारी सेवाएं',
            'appointment_booking': 'अपॉइंटमेंट बुकिंग',
            'appointment_desc': 'विशेषज्ञ डॉक्टरों के साथ अपनी सुविधानुसार अपॉइंटमेंट बुक करें।',
            'online_consultation': 'ऑनलाइन परामर्श',
            'consultation_desc': 'सुरक्षित वीडियो कॉल के माध्यम से डॉक्टरों से ऑनलाइन परामर्श लें।',
            'medicine_delivery': 'दवा वितरण',
            'medicine_desc': 'अपनी निर्धारित दवाएं अपने दरवाजे पर प्राप्त करें।',
            'health_records': 'स्वास्थ्य रिकॉर्ड',
            'records_desc': 'कभी भी, कहीं भी अपने स्वास्थ्य रिकॉर्ड तक पहुंचें और प्रबंधित करें।',
            
            // How it works
            'how_it_works': 'यह कैसे काम करता है',
            'create_account': 'खाता बनाएं',
            'account_desc': 'साइन अप करें और अपनी स्वास्थ्य प्रोफाइल पूरी करें',
            'choose_service': 'सेवा चुनें',
            'service_desc': 'आवश्यक स्वास्थ्य सेवा का चयन करें',
            'book_appointment_step': 'अपॉइंटमेंट बुक करें',
            'appointment_step_desc': 'अपनी यात्रा या ऑनलाइन परामर्श शेड्यूल करें',
            'get_treatment': 'उपचार प्राप्त करें',
            'treatment_desc': 'गुणवत्तापूर्ण स्वास्थ्य सेवा और फॉलो-अप प्राप्त करें',
            
            // Testimonials
            'testimonials': 'हमारे मरीज क्या कहते हैं',
            'testimonial_1': '"ई-सचत नाभा ने लंबी दूरी तय किए बिना किसी विशेषज्ञ से परामर्श करना बहुत आसान बना दिया। वीडियो परामर्श सहज था और डॉक्टर बहुत मददगार थे।"',
            'testimonial_2': '"दवा वितरण सेवा मेरे बुजुर्ग माता-पिता के लिए एक जीवनरक्षक है। हमें उनकी सभी दवाएं बिना किसी परेशानी के समय पर मिल जाती हैं।"',
            'testimonial_3': '"मेरे सभी स्वास्थ्य रिकॉर्ड एक ही स्थान पर होने से मेरी पुरानी बीमारी का प्रबंधन करना बहुत आसान हो गया है। मैं उन्हें आसानी से किसी भी डॉक्टर के साथ साझा कर सकता हूं।"',
            'patient': 'मरीज',
            'customer': 'ग्राहक',
            
            // Download app
            'download_app': 'ई-सचत नाभा डाउनलोड करें',
            'download_desc': 'हमारे मोबाइल एप्लिकेशन के साथ चलते-फिरते स्वास्थ्य सेवाओं तक पहुंचें। iOS और Android दोनों प्लेटफॉर्म पर उपलब्ध है।',
            
            // Footer
            'footer_tagline': 'बेहतर स्वास्थ्य की आपकी यात्रा यहाँ से शुरू होती है',
            'quick_links': 'त्वरित लिंक',
            'emergency_care': 'आपातकालीन देखभाल',
            'contact_us': 'संपर्क करें',
            'address': 'मेडिकल कॉम्प्लेक्स, नाभा, पंजाब',
            'privacy_policy': 'गोपनीयता नीति',
            'terms_service': 'सेवा की शर्तें'
        },
        pa: {
            // Navigation
            'home': 'ਘਰ',
            'services': 'ਸੇਵਾਵਾਂ',
            'doctors': 'ਡਾਕਟਰ',
            'appointments': 'ਅਪਾਇੰਟਮੈਂਟ',
            'health_records': 'ਸਿਹਤ ਰਿਕਾਰਡ',
            'medicine': 'ਦਵਾਈ',
            'contact': 'ਸੰਪਰਕ',
            
            // Hero section
            'hero_title': 'ਬਿਹਤਰ ਸਿਹਤ ਦੀ ਤੁਹਾਡੀ ਯਾਤਰਾ ਇੱਥੋਂ ਸ਼ੁਰੂ ਹੁੰਦੀ ਹੈ',
            'hero_desc': 'ਆਪਣੇ ਘਰ ਦੇ ਆਰਾਮ ਤੋਂ ਗੁਣਵੱਤਾ ਵਾਲੀਆਂ ਸਿਹਤ ਸੇਵਾਵਾਂ ਤੱਕ ਪਹੁੰਚ ਕਰੋ। ਅਪਾਇੰਟਮੈਂਟ ਬੁੱਕ ਕਰੋ, ਡਾਕਟਰਾਂ ਨਾਲ ਸਲਾਹ ਲਓ, ਅਤੇ ਆਪਣੇ ਸਿਹਤ ਰਿਕਾਰਡ ਨੂੰ ਇੱਕ ਹੀ ਥਾਂ 'ਤੇ ਪ੍ਰਬੰਧਿਤ ਕਰੋ।',
            'book_appointment': 'ਅਪਾਇੰਟਮੈਂਟ ਬੁੱਕ ਕਰੋ',
            'consult_online': 'ਔਨਲਾਈਨ ਸਲਾਹ',
            
            // Services
            'our_services': 'ਸਾਡੀਆਂ ਸੇਵਾਵਾਂ',
            'appointment_booking': 'ਅਪਾਇੰਟਮੈਂਟ ਬੁਕਿੰਗ',
            'appointment_desc': 'ਵਿਸ਼ੇਸ਼ਜ਼ ਡਾਕਟਰਾਂ ਨਾਲ ਆਪਣੀ ਸਹੂਲਤ ਅਨੁਸਾਰ ਅਪਾਇੰਟਮੈਂਟ ਬੁੱਕ ਕਰੋ।',
            'online_consultation': 'ਔਨਲਾਈਨ ਸਲਾਹ',
            'consultation_desc': 'ਸੁਰੱਖਿਅਤ ਵੀਡੀਓ ਕਾਲਾਂ ਦੁਆਰਾ ਡਾਕਟਰਾਂ ਨਾਲ ਔਨਲਾਈਨ ਸਲਾਹ ਲਓ।',
            'medicine_delivery': 'ਦਵਾਈ ਵਿਤਰਣ',
            'medicine_desc': 'ਆਪਣੀਆਂ ਨਿਰਧਾਰਤ ਦਵਾਈਆਂ ਆਪਣੇ ਦਰਵਾਜ਼ੇ 'ਤੇ ਪ੍ਰਾਪਤ ਕਰੋ।',
            'health_records': 'ਸਿਹਤ ਰਿਕਾਰਡ',
            'records_desc': 'ਕਦੇ ਵੀ, ਕਹੀਂ ਵੀ ਆਪਣੇ ਸਿਹਤ ਰਿਕਾਰਡਾਂ ਤੱਕ ਪਹੁੰਚ ਕਰੋ ਅਤੇ ਪ੍ਰਬੰਧਿਤ ਕਰੋ।',
            
            // How it works
            'how_it_works': 'ਇਹ ਕਿਵੇਂ ਕੰਮ ਕਰਦਾ ਹੈ',
            'create_account': 'ਖਾਤਾ ਬਣਾਓ',
            'account_desc': 'ਸਾਈਨ ਅਪ ਕਰੋ ਅਤੇ ਆਪਣੀ ਸਿਹਤ ਪਰੋਫਾਈਲ ਪੂਰੀ ਕਰੋ',
            'choose_service': 'ਸੇਵਾ ਚੁਣੋ',
            'service_desc': 'ਲੋੜੀਂਦੀ ਸਿਹਤ ਸੇਵਾ ਚੁਣੋ',
            'book_appointment_step': 'ਅਪਾਇੰਟਮੈਂਟ ਬੁੱਕ ਕਰੋ',
            'appointment_step_desc': 'ਆਪਣੀ ਯਾਤਰਾ ਜਾਂ ਔਨਲਾਈਨ ਸਲਾਹ ਸ਼ੈਡਿਊਲ ਕਰੋ',
            'get_treatment': 'ਇਲਾਜ ਪ੍ਰਾਪਤ ਕਰੋ',
            'treatment_desc': 'ਗੁਣਵੱਤਾਪੂਰਨ ਸਿਹਤ ਸੇਵਾ ਅਤੇ ਫੋਲੋ-ਅਪ ਪ੍ਰਾਪਤ ਕਰੋ',
            
            // Testimonials
            'testimonials': 'ਸਾਡੇ ਮਰੀਜ਼ ਕੀ ਕਹਿੰਦੇ ਹਨ',
            'testimonial_1': '"ਈ-ਸਚਤ ਨਾਭਾ ਨੇ ਲੰਬੀ ਦੂਰੀ ਤੈਅ ਕੀਤੇ ਬਿਨਾਂ ਕਿਸੇ ਵਿਸ਼ੇਸ਼ਜ਼ ਨਾਲ ਸਲਾਹ ਲੈਣਾ ਬਹੁਤ ਆਸਾਨ ਬਣਾ ਦਿੱਤਾ। ਵੀਡੀਓ ਸਲਾਹ ਸਹਿਜ ਸੀ ਅਤੇ ਡਾਕਟਰ ਬਹੁਤ ਮਦਦਗਾਰ ਸਨ।"',
            'testimonial_2': '"ਦਵਾਈ ਵਿਤਰਣ ਸੇਵਾ ਮੇਰੇ ਬਜ਼ੁਰਗ ਮਾਤਾ-ਪਿਤਾ ਲਈ ਇੱਕ ਜੀਵਨਰੱਖਾ ਹੈ। ਸਾਨੂੰ ਉਨ੍ਹਾਂ ਦੀਆਂ ਸਾਰੀਆਂ ਦਵਾਈਆਂ ਬਿਨਾਂ ਕਿਸੇ ਪਰੇਸ਼ਾਨੀ ਦੇ ਸਮੇਂ ਸਿਰ ਮਿਲ ਜਾਂਦੀਆਂ ਹਨ।"',
            'testimonial_3': '"ਮੇਰੇ ਸਾਰੇ ਸਿਹਤ ਰਿਕਾਰਡ ਇੱਕ ਹੀ ਥਾਂ 'ਤੇ ਹੋਣ ਨਾਲ ਮੇਰੀ ਲੰਬੇ ਸਮੇਂ ਦੀ ਬਿਮਾਰੀ ਦਾ ਪ੍ਰਬੰਧਨ ਕਰਨਾ ਬਹੁਤ ਆਸਾਨ ਹੋ ਗਿਆ ਹੈ। ਮੈਂ ਉਨ੍ਹਾਂ ਨੂੰ ਆਸਾਨੀ ਨਾਲ ਕਿਸੇ ਵੀ ਡਾਕਟਰ ਨਾਲ ਸਾਂਝਾ ਕਰ ਸਕਦਾ ਹਾਂ।"',
            'patient': 'ਮਰੀਜ਼',
            'customer': 'ਗ੍ਰਾਹਕ',
            
            // Download app
            'download_app': 'ਈ-ਸਚਤ ਨਾਭਾ ਡਾਉਨਲੋਡ ਕਰੋ',
            'download_desc': 'ਸਾਡੇ ਮੋਬਾਈਲ ਐਪਲੀਕੇਸ਼ਨ ਨਾਲ ਚਲਦੇ-ਫਿਰਦੇ ਸਿਹਤ ਸੇਵਾਵਾਂ ਤੱਕ ਪਹੁੰਚ ਕਰੋ। iOS ਅਤੇ Android ਦੋਵਾਂ ਪਲੇਟਫਾਰਮਾਂ 'ਤੇ ਉਪਲਬਧ ਹੈ।',
            
            // Footer
            'footer_tagline': 'ਬਿਹਤਰ ਸਿਹਤ ਦੀ ਤੁਹਾਡੀ ਯਾਤਰਾ ਇੱਥੋਂ ਸ਼ੁਰੂ ਹੁੰਦੀ ਹੈ',
            'quick_links': 'ਤੁਰੰਤ ਲਿੰਕ',
            'emergency_care': 'ਐਮਰਜੈਂਸੀ ਕੇਅਰ',
            'contact_us': 'ਸਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰੋ',
            'address': 'ਮੈਡੀਕਲ ਕੰਪਲੈਕਸ, ਨਾਭਾ, ਪੰਜਾਬ',
            'privacy_policy': 'ਪਰਾਈਵੇਸੀ ਨੀਤੀ',
            'terms_service': 'ਸੇਵਾ ਦੀਆਂ ਸ਼ਰਤਾਂ'
        }
    };

    // Set default language
    let currentLanguage = localStorage.getItem('language') || 'en';
    
    // Update language button text
    function updateLanguageButton() {
        const languageBtn = document.getElementById('current-language');
        if (languageBtn) {
            if (currentLanguage === 'en') languageBtn.textContent = 'English';
            if (currentLanguage === 'hi') languageBtn.textContent = 'हिंदी';
            if (currentLanguage === 'pa') languageBtn.textContent = 'ਪੰਜਾਬੀ';
        }
    }
    
    // Translate page content
    function translatePage(lang) {
        const elements = document.querySelectorAll('[data-translate]');
        elements.forEach(element => {
            const key = element.getAttribute('data-translate');
            if (translations[lang] && translations[lang][key]) {
                element.textContent = translations[lang][key];
            }
        });
        
        // Update language button
        updateLanguageButton();
        
        // Save language preference
        localStorage.setItem('language', lang);
        currentLanguage = lang;
    }
    
    // Language selector functionality
    const languageOptions = document.querySelectorAll('.language-option');
    languageOptions.forEach(option => {
        option.addEventListener('click', function() {
            const lang = this.getAttribute('data-lang');
            translatePage(lang);
        });
    });
    
    // Mobile menu functionality
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const mobileNav = document.querySelector('.mobile-nav');
    
    if (mobileMenuBtn && mobileNav) {
        mobileMenuBtn.addEventListener('click', function() {
            mobileNav.classList.toggle('show');
        });
    }
    
    // Initialize page with saved language
    translatePage(currentLanguage);
});

// Existing functionality for view toggle
document.addEventListener('DOMContentLoaded', function() {
    const viewToggle = document.getElementById('viewToggle');
    const patientOption = document.querySelector('.patient-option');
    const doctorOption = document.querySelector('.doctor-option');
    
    if (viewToggle) {
        viewToggle.addEventListener('change', function() {
            if (this.checked) {
                patientOption.classList.remove('active');
                doctorOption.classList.add('active');
            } else {
                patientOption.classList.add('active');
                doctorOption.classList.remove('active');
            }
        });
    }
});

// Existing functionality for view toggle
document.addEventListener('DOMContentLoaded', function() {
    const viewToggle = document.getElementById('viewToggle');
    const patientOption = document.querySelector('.patient-option');
    const doctorOption = document.querySelector('.doctor-option');
    
    if (viewToggle) {
        viewToggle.addEventListener('change', function() {
            if (this.checked) {
                patientOption.classList.remove('active');
                doctorOption.classList.add('active');
            } else {
                patientOption.classList.add('active');
                doctorOption.classList.remove('active');
            }
        });
    }
    
    // Add click handlers for service cards
    const serviceCards = document.querySelectorAll('.service-card');
    serviceCards.forEach(card => {
        card.addEventListener('click', function() {
            // Add your service card click functionality here
            console.log('Service card clicked:', this.querySelector('h3').textContent);
        });
    });
    
    // Add click handlers for hero buttons
    const heroButtons = document.querySelectorAll('.hero-buttons button');
    heroButtons.forEach(button => {
        button.addEventListener('click', function() {
            if (this.classList.contains('btn-primary')) {
                // Book appointment functionality
                console.log('Book appointment clicked');
            } else {
                // Consult online functionality
                console.log('Consult online clicked');
            }
        });
    });
});