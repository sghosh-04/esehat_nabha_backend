// DOM Content Loaded
document.addEventListener('DOMContentLoaded', async function () {
    setCurrentDateTime();
    await loadDoctorData(); // load from backend
    setupEventListeners();
    setInterval(setCurrentDateTime, 60000);
});

// Set current date and time
function setCurrentDateTime() {
    const now = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    document.getElementById('currentDate').textContent = now.toLocaleDateString('en-US', options);
    document.getElementById('currentTime').textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

// Load doctor data from backend
async function loadDoctorData() {
    try {
        const doctorLicense = localStorage.getItem('doctorLicense');
        const token = localStorage.getItem('doctorToken');

        if (!doctorLicense || !token) throw new Error('Missing credentials. Please login again.');

        console.log("Doctor License:", doctorLicense);
        console.log("Doctor Token:", token);

        const res = await fetch(`http://localhost:5004/api/doctors/${doctorLicense}`, {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${token}`,
                "Content-Type": "application/json"
            }
        });

        if (!res.ok) {
            throw new Error(`Failed to fetch doctor details: ${res.status}`);
        }

        const data = await res.json();
        populateDoctorData(data);
    } catch (error) {
        console.error('Error loading doctor data:', error);
        alert('❌ Failed to load doctor data. Please login again.');
        window.location.href = 'index.html';
    }
}


// Populate doctor data in the UI
function populateDoctorData(data) {
    const [firstName, lastName] = data.name.split(' ');

    document.getElementById('doctorName').textContent = firstName;
    document.getElementById('doctorFirstName').textContent = firstName;
    document.getElementById('doctorFullName').textContent = `Dr. ${data.name}`;
    document.getElementById('doctorEmail').textContent = data.email;
    document.getElementById('doctorPhone').textContent = data.phonenumber;
    document.getElementById('doctorSpecialization').textContent = data.specialization;
    document.getElementById('doctorExperience').textContent = `${data.experience} years of experience`;
    document.getElementById('doctorRegNumber').textContent = data.license_number;

   if (data.clinic_address) {
        document.getElementById('doctorAddress').textContent = data.clinic_address;
    }


    // Populate specializations
    if (Array.isArray(data.specializations)) {
        const specializationNames = data.specializations.map(s => (typeof s === 'string' ? s : s.name));
        updateList('specializationsList', specializationNames);
    } else {
        updateList('specializationsList', []);
    }

    // Populate qualifications
    if (Array.isArray(data.qualifications)) {
        const qualificationNames = data.qualifications.map(q => (typeof q === 'string' ? q : q.name));
        updateList('qualificationsList', qualificationNames);
    } else {
        updateList('qualificationsList', []);
    }
}

// Helper to update UL lists
function updateList(elementId, items) {
    const ul = document.getElementById(elementId);
    ul.innerHTML = '';
    items.forEach(item => {
        const li = document.createElement('li');
        li.textContent = item;
        ul.appendChild(li);
    });
}

// Setup event listeners
function setupEventListeners() {
    document.getElementById('editProfileBtn')?.addEventListener('click', () => {
        document.getElementById('editProfileModal').style.display = 'flex';
    });
    document.querySelector('.close')?.addEventListener('click', closeEditModal);
    document.getElementById('cancelEdit')?.addEventListener('click', closeEditModal);
    document.getElementById('profileForm')?.addEventListener('submit', handleProfileUpdate);
    document.getElementById('logoutBtn')?.addEventListener('click', handleLogout);

    window.addEventListener('click', event => {
        if (event.target === document.getElementById('editProfileModal')) closeEditModal();
    });

    document.querySelector('.hamburger')?.addEventListener('click', () => {
        document.querySelector('.nav-menu').classList.toggle('active');
        document.querySelector('.hamburger').classList.toggle('active');
    });
}

function closeEditModal() {
    document.getElementById('editProfileModal').style.display = 'none';
}

// Handle profile update
function handleProfileUpdate(e) {
    e.preventDefault();
    const updatedData = {
        name: document.getElementById('editFirstName').value + ' ' + document.getElementById('editLastName').value,
        email: document.getElementById('editEmail').value,
        phonenumber: document.getElementById('editPhone').value,
        specialization: document.getElementById('editSpecialization').value,
        experience: document.getElementById('editExperience').value,
        license_number: document.getElementById('editRegNumber').value
    };

    // Optionally save locally and update UI
    localStorage.setItem('doctorData', JSON.stringify(updatedData));
    populateDoctorData(updatedData);
    closeEditModal();
    alert('Profile updated successfully!');
}

// Handle logout
function handleLogout(e) {
    e.preventDefault();
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('doctorId');
        localStorage.removeItem('doctorToken');
        window.location.href = '../login-page/index.html';
    }
}
